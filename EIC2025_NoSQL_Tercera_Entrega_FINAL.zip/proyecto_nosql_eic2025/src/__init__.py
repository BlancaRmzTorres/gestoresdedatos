"""Funciones auxiliares del proyecto."""
