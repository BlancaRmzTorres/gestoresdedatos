@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo ENDUTIH 2024-2025 - INSTALACION
 echo ============================================
where python >nul 2>&1
if errorlevel 1 (
 echo ERROR: Python no se encuentra. Instale Python 3.11 y habilite PATH.
 goto :fail
)
python -c "import sys; assert sys.version_info >= (3,10), 'Se requiere Python 3.10 o superior'"
if errorlevel 1 goto :fail
python -m pip install -r requirements.txt
if errorlevel 1 (
 echo ERROR: Fallo la instalacion de dependencias. Revise su conexion a Internet.
 goto :fail
)
python -c "from pymongo import MongoClient; MongoClient('mongodb://localhost:27017/',serverSelectionTimeoutMS=8000).admin.command('ping'); print('MongoDB responde correctamente')"
if errorlevel 1 (
 echo ERROR: MongoDB no responde en localhost:27017. Inicie MongoDB Community Server.
 goto :fail
)
if not exist "datos\endutih2024_bd_dbf.zip" (
 echo ERROR: Falta el ZIP original de ENDUTIH 2024.
 goto :fail
)
if not exist "datos\endutih2025_bd_dbf.zip" (
 echo ERROR: Falta el ZIP original de ENDUTIH 2025.
 goto :fail
)
echo.
echo Cargando hogares 2024 (upsert por identificador, sin borrar colecciones)...
python scripts\cargar_hogares.py --zip "datos\endutih2024_bd_dbf.zip" --year 2024 --load
if errorlevel 1 goto :fail
echo.
echo Cargando hogares 2025...
python scripts\cargar_hogares.py --zip "datos\endutih2025_bd_dbf.zip" --year 2025 --load
if errorlevel 1 goto :fail
python scripts\verificar_instalacion.py
if errorlevel 1 goto :fail
echo.
echo INSTALACION COMPLETADA. Ejecute INICIAR_DASHBOARD.bat
echo.
pause
exit /b 0
:fail
echo.
echo No se completo la instalacion. Consulte README.md.
pause
exit /b 1
