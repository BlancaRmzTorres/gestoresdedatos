import streamlit as st
import pandas as pd
import plotly.express as px
from pymongo import MongoClient

st.set_page_config(page_title='ENDUTIH | Comparativa 2024-2025',layout='wide')
st.title('ENDUTIH 2024 vs 2025 · Observatorio digital')
st.caption('Análisis descriptivo con datos INEGI. Los resultados ponderados requieren validación metodológica antes de presentarse como estimaciones oficiales.')
@st.cache_resource
def connect():
    c=MongoClient('mongodb://localhost:27017/',serverSelectionTimeoutMS=5000);c.admin.command('ping');return c
try:db=connect()['madurez_digital_endutih']
except Exception as e:st.error(f'No se pudo conectar a MongoDB: {e}');st.stop()

cols={2024:'hogares_completos_2024',2025:'hogares_completos_2025'}
original={2024:'personas_endutih_2024',2025:'personas_endutih'}
with st.sidebar:
    st.header('Filtros')
    years=st.multiselect('Ediciones',[2024,2025],default=[2024,2025])
    entity=st.text_input('Código de entidad (01–32), vacío = todas','').strip()
    dimension=st.selectbox('Dimensión',['Internet en el hogar','Televisión de paga','Equipamiento tecnológico'])
    st.caption('Para indicadores de hogares se priorizan las colecciones de tablas completas.')

config={'Internet en el hogar':('P4_4','Con internet'), 'Televisión de paga':('P5_1','Con televisión de paga'), 'Equipamiento tecnológico':('P4_1_1','Código 1: equipo P4_1_1 (pendiente de etiqueta oficial)')}
field,label=config[dimension]
rows=[]
for year in years:
    full=cols[year] in db.list_collection_names()
    name=cols[year] if full else original[year]
    if name not in db.list_collection_names():continue
    if full:
        path=field;weight='$FAC_HOG';ent='entidad_codigo'
    else:
        path=('equipamiento' if field.startswith('P4_') else 'conectividad')+'.hogar_preguntas_originales.'+field
        weight='$metadatos.factor_expansion_hogar_codigo';ent='sociodemografia.entidad_codigo'
    query={ent:entity} if entity else {}
    pipeline=[{'$match':query},{'$project':{'code':'$'+path,'wt':{'$convert':{'input':weight,'to':'double','onError':None,'onNull':None}}}},{'$match':{'code':{'$in':['1','2']},'wt':{'$gt':0}}},{'$group':{'_id':'$code','n':{'$sum':1},'weighted':{'$sum':'$wt'}}}]
    data={r['_id']:r for r in db[name].aggregate(pipeline)}
    yes=data.get('1',{}).get('weighted',0);no=data.get('2',{}).get('weighted',0)
    pct=100*yes/(yes+no) if yes+no else None
    rows.append({'Año':year,'Código 1 (%)':pct,'Código 2 (%)':100-pct if pct is not None else None,'Registros':sum(x['n'] for x in data.values()),'Origen':'Tabla completa DBF' if full else 'Personas seleccionadas (provisional)','Total ponderado':yes+no})

if not rows:st.warning('No hay colecciones para los filtros seleccionados.');st.stop()
df=pd.DataFrame(rows)
st.subheader(dimension)
st.dataframe(df,hide_index=True,width='stretch')
if len(df)==2 and set(df['Año'])=={2024,2025} and df['Código 1 (%)'].notna().all():
    x=df.set_index('Año')['Código 1 (%)'];st.metric('Variación 2025 − 2024',f'{x[2025]-x[2024]:+.2f} puntos porcentuales')
fig=px.bar(df,x='Año',y=['Código 1 (%)','Código 2 (%)'],barmode='group',labels={'value':'Porcentaje ponderado','variable':'Categoría'},title='Distribución de respuestas ponderadas')
fig.update_yaxes(range=[0,100]);st.plotly_chart(fig,width='stretch')
st.info('Interpretación: se comparan distribuciones ponderadas de respuestas. Las tablas completas de hogares se priorizan cuando están cargadas. Los resultados requieren contraste con la metodología y tabulados oficiales del INEGI. No interpretar equipamiento P4_1_1 hasta verificar el diccionario.')
st.subheader('Explorador NoSQL')
with st.expander('Ver ejemplos de consultas MongoDB'):
    st.code('db.hogares_completos_2025.find({entidad_codigo: "01"}, {P4_4: 1, FAC_HOG: 1}).limit(10)',language='javascript')
    st.code('db.hogares_completos_2025.aggregate([{ $group: { _id: "$P4_4", registros: { $sum: 1 }, ponderado: { $sum: { $toDouble: "$FAC_HOG" } } } }])',language='javascript')
st.code('db.hogares_completos_2024.aggregate([{ $group: { _id: "$P4_4", hogares: { $sum: 1 } } }])',language='javascript')
st.write('Colecciones disponibles:',', '.join(db.list_collection_names()))
st.subheader('Limitaciones y conclusiones')
st.markdown('''- Comparación transversal entre ediciones, no seguimiento de individuos.\n- Porcentajes ponderados con FAC_HOG; validar universos, valores no respuesta y diseño muestral contra tabulados oficiales.\n- Los conteos de documentos no equivalen a cambios poblacionales.\n- No se atribuye causalidad a las diferencias observadas.\n- Para publicar conclusiones nacionales, usar ambas tablas completas y documentación oficial.''')
st.download_button('Descargar resultados CSV',df.to_csv(index=False).encode('utf-8-sig'),'indicadores_endutih.csv','text/csv')
