// Consulta 2: conteos y suma de factores de expansion 2025
use('madurez_digital_endutih');
db.hogares_completos_2025.aggregate([{$match:{P4_4:{$in:['1','2']}}},{$group:{_id:'$P4_4',hogares:{$sum:1},hogares_ponderados:{$sum:{$toDouble:'$FAC_HOG'}}}},{$sort:{_id:1}}]);
