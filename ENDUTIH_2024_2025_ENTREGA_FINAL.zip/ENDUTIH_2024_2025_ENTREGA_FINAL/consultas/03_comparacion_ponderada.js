// Consulta 3: porcentajes ponderados por anio
use('madurez_digital_endutih');
for (const year of [2024,2025]) {
 const r=db.getCollection('hogares_completos_'+year).aggregate([{$match:{P4_4:{$in:['1','2']}}},{$group:{_id:null,total:{$sum:{$toDouble:'$FAC_HOG'}},si:{$sum:{$cond:[{$eq:['$P4_4','1']},{$toDouble:'$FAC_HOG'},0]}}}},{$project:{_id:0,total:1,si:1,porcentaje:{$round:[{$multiply:[{$divide:['$si','$total']},100]},4]}}}]).toArray();
 printjson({anio:year,resultado:r});
}
