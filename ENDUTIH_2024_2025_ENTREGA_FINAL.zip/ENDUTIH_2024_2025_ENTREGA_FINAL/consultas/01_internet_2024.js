// Consulta 1: conteo muestral de internet en hogares 2024
use('madurez_digital_endutih');
db.hogares_completos_2024.aggregate([{$group:{_id:'$P4_4',hogares:{$sum:1}}},{$sort:{_id:1}}]);
