// Consulta 5: television de paga (P5_1) por anio
use('madurez_digital_endutih');
for (const year of [2024,2025]) {
 print('ENDUTIH '+year);
 printjson(db.getCollection('hogares_completos_'+year).aggregate([{$match:{P5_1:{$in:['1','2']}}},{$group:{_id:'$P5_1',hogares:{$sum:1},ponderado:{$sum:{$toDouble:'$FAC_HOG'}}}},{$sort:{_id:1}}]).toArray());
}
