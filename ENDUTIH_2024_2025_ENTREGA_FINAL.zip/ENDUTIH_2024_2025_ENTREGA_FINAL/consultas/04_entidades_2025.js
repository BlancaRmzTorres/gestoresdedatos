// Consulta 4: diez codigos de entidad con mayor porcentaje ponderado en 2025
// Validar la codificacion de entidad_codigo antes de interpretar geograficamente.
use('madurez_digital_endutih');
db.hogares_completos_2025.aggregate([{$match:{entidad_codigo:{$regex:'^[0-9]{2}$'},P4_4:{$in:['1','2']}}},{$group:{_id:'$entidad_codigo',hogares:{$sum:1},total:{$sum:{$toDouble:'$FAC_HOG'}},si:{$sum:{$cond:[{$eq:['$P4_4','1']},{$toDouble:'$FAC_HOG'},0]}}}},{$project:{_id:0,entidad:'$_id',hogares:1,porcentaje:{$round:[{$multiply:[{$divide:['$si','$total']},100]},2]}}},{$sort:{porcentaje:-1}},{$limit:10}]);
