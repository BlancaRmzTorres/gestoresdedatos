# ENDUTIH 2024-2025 | Proyecto NoSQL reproducible

**Entrega para Windows 10/11.** Proyecto de análisis descriptivo comparativo con MongoDB, PyMongo, Streamlit y Plotly.

## Requisitos previos

- Python 3.11 recomendado (3.10 o superior) con `python` accesible desde CMD.
- MongoDB Community Server instalado y **en ejecución** en `localhost:27017`, sin autenticación para esta demostración local.
- Acceso a Internet para instalar paquetes de `requirements.txt` la primera vez.
- Aproximadamente 1 GB de espacio libre para dependencias, carga y archivos temporales.

## Inicio rápido

1. Extraer el ZIP completo en cualquier carpeta, conservando su estructura.
2. Verificar que MongoDB Community Server está ejecutándose (servicio MongoDB en Windows).
3. Hacer doble clic en **`INSTALAR_PROYECTO.bat`**. Esperar a que confirme `INSTALACION COMPLETADA`.
4. Hacer doble clic en **`INICIAR_DASHBOARD.bat`**.
5. Abrir `http://localhost:8501` si el navegador no se abre automáticamente. Mantener la ventana del dashboard abierta.

La instalación crea/actualiza por clave los documentos de `hogares_completos_2024` y `hogares_completos_2025` en la base `madurez_digital_endutih`. **No borra ni altera** `personas_endutih` o `personas_endutih_2024`. No es necesario cargar las colecciones de personas para el dashboard: las dos colecciones de hogares incluidas son suficientes.

**Importante:** no ejecutar el instalador contra una base MongoDB con información de producción. El script usa `ReplaceOne(..., upsert=True)` en las colecciones de hogares y puede reemplazar documentos con la misma clave.

## Si los .bat no funcionan

Abrir CMD en la carpeta descomprimida y ejecutar:

```cmd
python -m pip install -r requirements.txt
python scripts\cargar_hogares.py --zip "datos\endutih2024_bd_dbf.zip" --year 2024 --load
python scripts\cargar_hogares.py --zip "datos\endutih2025_bd_dbf.zip" --year 2025 --load
python scripts\verificar_instalacion.py
python -m streamlit run dashboard\app.py
```

Si `pip` muestra `getaddrinfo failed`, verificar la resolución DNS y la conectividad a `pypi.org` y `files.pythonhosted.org`; no es un error del proyecto. Si MongoDB exige usuario/contraseña o usa otro puerto, adaptar la URI en los scripts y en `dashboard/app.py` antes de ejecutar.

## Contenido

- `datos/`: ZIP oficiales de las bases DBF ENDUTIH 2024 y 2025; no se requiere descargarlos aparte.
- `scripts/cargar_hogares.py`: lector DBF y carga a MongoDB.
- `scripts/verificar_instalacion.py`: verifica el número de documentos cargados.
- `dashboard/app.py`: dashboard interactivo y exportación CSV.
- `consultas/`: cinco consultas para la consola MONGOSH de MongoDB Compass (copiar el contenido de cada archivo).
- `documentacion/`: informe técnico Word.
- `evidencias/`: capturas de la ejecución original.
- `resultados/`: validaciones previas de los DBF.

## Resultados de referencia

| Indicador | 2024 | 2025 |
|---|---:|---:|
| Registros de hogares | 58,080 | 57,810 |
| P4_4 = 1 | 42,638 | 45,070 |
| P4_4 = 2 | 15,442 | 12,740 |
| Suma FAC_HOG con P4_4 = 1 | 28,772,674 | 31,058,142 |
| Suma FAC_HOG con P4_4 = 2 | 10,317,735 | 8,619,356 |
| Porcentaje ponderado P4_4 = 1 | 73.6055 % | 78.2765 % |

**Advertencia metodológica:** estos cálculos se reproducen sobre tablas completas de hogares con `FAC_HOG`; no se presentan como tabulados oficiales del INEGI sin validar universos, diccionarios de variables y metodología. El campo `P4_1_1` se muestra como exploratorio hasta verificar su etiqueta. Los conteos muestrales no equivalen a totales poblacionales.

## Verificación rápida

El script `verificar_instalacion.py` debe mostrar exactamente 58,080 documentos en `hogares_completos_2024` y 57,810 en `hogares_completos_2025`. El dashboard mostrará `Tabla completa DBF` como origen.

## Fuente

INEGI, Encuesta Nacional sobre Disponibilidad y Uso de Tecnologías de la Información en los Hogares (ENDUTIH), ediciones 2024 y 2025. Archivos DBF suministrados junto con este paquete.
