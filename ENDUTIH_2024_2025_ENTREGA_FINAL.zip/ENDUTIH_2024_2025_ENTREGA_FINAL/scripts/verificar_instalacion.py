from pymongo import MongoClient
from pathlib import Path
import zipfile

EXPECTED={2024:58080,2025:57810}
client=MongoClient('mongodb://localhost:27017/',serverSelectionTimeoutMS=8000)
try:
    client.admin.command('ping')
    db=client['madurez_digital_endutih']
    for year,expected in EXPECTED.items():
        name=f'hogares_completos_{year}'
        count=db[name].count_documents({})
        print(f'{name}: {count:,} documentos (esperados: {expected:,})')
        if count != expected:
            raise SystemExit(f'ERROR: coleccion {name} incompleta; revise la carga.')
    print('OK: ambas colecciones completas estan listas para el dashboard.')
finally:
    client.close()
