"""Importa hogares completos ENDUTIH desde DBF ZIP a una colección NUEVA.
Nunca escribe en personas_endutih ni personas_endutih_2024.
"""
import argparse, zipfile, sys, json, collections
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
# Lector DBF autocontenido
import struct

def rows(z,name):
    with z.open(name) as f:
        h=f.read(32); total=struct.unpack_from('<I',h,4)[0]; hs=struct.unpack_from('<H',h,8)[0]; width=struct.unpack_from('<H',h,10)[0]
        defs=[];pos=1;consumed=32
        while consumed < hs:
            b=f.read(1);consumed+=1
            if b==b'\r':break
            rest=f.read(31);consumed+=31
            d=b+rest;label=d[:11].split(b'\0')[0].decode('ascii').strip();ln=d[16]
            if label and label!='_NullFlags':defs.append((label,pos,ln))
            pos+=ln
        f.read(hs-consumed)
        for _ in range(total):
            rec=f.read(width)
            if len(rec)!=width:raise ValueError('DBF truncado')
            if rec[:1]==b'*':continue
            yield {k:(rec[p:p+n].decode('latin-1').strip() or None) for k,p,n in defs}

def main():
    p=argparse.ArgumentParser();p.add_argument('--zip',required=True);p.add_argument('--year',type=int,choices=[2024,2025],required=True);p.add_argument('--uri',default='mongodb://localhost:27017/');p.add_argument('--db',default='madurez_digital_endutih');p.add_argument('--load',action='store_true');a=p.parse_args()
    filename='tic_2024_hogares.DBF' if a.year==2024 else 'ti25hog.dbf'
    dest=f'hogares_completos_{a.year}'
    counter=collections.Counter();weights=collections.Counter();seen=set();batch=[];total=0
    if a.load:
        from pymongo import MongoClient, ReplaceOne
    client=MongoClient(a.uri,serverSelectionTimeoutMS=10000) if a.load else None
    try:
        if client:client.admin.command('ping')
        with zipfile.ZipFile(a.zip) as z:
            matches=[n for n in z.namelist() if Path(n).name.lower()==filename.lower()]
            if len(matches)!=1:raise ValueError(f'Se esperaba {filename} en ZIP, encontrados: {matches}')
            for r in rows(z,matches[0]):
                k=tuple(r.get(x) for x in ('UPM','VIV_SEL','HOGAR'))
                if any(v is None for v in k) or k in seen:raise ValueError(f'Clave inválida/duplicada: {k}')
                seen.add(k);total+=1
                code=r.get('P4_4');counter[str(code)]+=1
                try:
                    wt=float(r['FAC_HOG']);assert wt>0
                    weights[str(code)]+=wt
                except (TypeError,ValueError,AssertionError):pass
                if client:
                    doc={'_id':f'{a.year}|'+ '|'.join(k),'anio':a.year,'UPM':k[0],'VIV_SEL':k[1],'HOGAR':k[2], 'entidad_codigo':r.get('CVE_ENT') or k[0][:2], 'FAC_HOG':r.get('FAC_HOG'),'P4_4':code,'P5_1':r.get('P5_1'), 'P4_1_1':r.get('P4_1_1'),'P4_1_2':r.get('P4_1_2'),'P4_1_3':r.get('P4_1_3'), 'fuente_tabla':matches[0]}
                    batch.append(ReplaceOne({'_id':doc['_id']},doc,upsert=True))
                    if len(batch)>=500:client[a.db][dest].bulk_write(batch,ordered=False);batch.clear()
            if client and batch:client[a.db][dest].bulk_write(batch,ordered=False)
        report={'anio':a.year,'tabla':filename,'registros':total,'codigos_P4_4':dict(counter),'ponderados_P4_4':dict(weights),'porcentaje_codigo_1':round(100*weights['1']/(weights['1']+weights['2']),4) if weights['1']+weights['2'] else None,'coleccion':dest if client else None,'validacion':'reproduccion sobre tabla completa; contrastar con metodologia INEGI'}
        Path(f'validacion_hogares_{a.year}.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
        print(json.dumps(report,indent=2,ensure_ascii=False))
    finally:
        if client:client.close()
if __name__=='__main__':main()
