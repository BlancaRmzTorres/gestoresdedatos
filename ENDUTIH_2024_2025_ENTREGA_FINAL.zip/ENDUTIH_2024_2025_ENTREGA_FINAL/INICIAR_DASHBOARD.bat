@echo off
setlocal
cd /d "%~dp0"
echo ENDUTIH 2024-2025 - Iniciando dashboard...
python scripts\verificar_instalacion.py
if errorlevel 1 (
 echo ERROR: Datos no disponibles. Ejecute INSTALAR_PROYECTO.bat primero.
 pause
 exit /b 1
)
python -m streamlit run dashboard\app.py
if errorlevel 1 (
 echo ERROR al iniciar Streamlit.
 pause
 exit /b 1
)
